import json
import os
import requests
from bs4 import BeautifulSoup

# Hugging Face API
HF_API_URL = "https://api-inference.huggingface.co/models/facebook/bart-large-cnn"
HF_API_TOKEN = os.environ.get("HF_API_TOKEN")

def extract_text(url):
    """Extracts readable text from a news article using requests + BeautifulSoup."""
    response = requests.get(url, timeout=10)
    soup = BeautifulSoup(response.text, "html.parser")

    # Collect all paragraphs
    paragraphs = soup.find_all("p")
    text = " ".join(p.get_text() for p in paragraphs)
    return text.strip()[:3000]  # limit text length

def summarize_text(text):
    headers = {"Authorization": f"Bearer {HF_API_TOKEN}"}
    payload = {"inputs": text[:1000]}  # limit size for API
    response = requests.post(HF_API_URL, headers=headers, json=payload)
    result = response.json()
    if isinstance(result, list) and "summary_text" in result[0]:
        return result[0]["summary_text"]
    else:
        return "Unable to summarize the article."

def lambda_handler(event, context):
    try:
        body = json.loads(event["body"])
        url = body.get("url")

        if not url:
            return {"statusCode": 400, "body": json.dumps({"error": "Missing 'url'"})}

        article_text = extract_text(url)
        if not article_text:
            return {"statusCode": 400, "body": json.dumps({"error": "No text found in the article"})}

        summary = summarize_text(article_text)
        return {
            "statusCode": 200,
            "headers": {"Content-Type": "application/json"},
            "body": json.dumps({"summary": summary})
        }

    except Exception as e:
        return {"statusCode": 500, "body": json.dumps({"error": str(e)})}
